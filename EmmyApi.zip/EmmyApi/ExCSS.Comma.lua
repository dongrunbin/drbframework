﻿---@class Comma : Term
---@public
---@return string
function Comma:ToString() end
