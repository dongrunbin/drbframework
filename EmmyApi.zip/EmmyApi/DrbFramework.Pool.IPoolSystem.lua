﻿---@class IPoolSystem
---@field public PoolCount number
