﻿---@class LoadAssetBundleBytesCompleteEventHandler : MulticastDelegate
---@public
---@param args LoadAssetBundleBytesCompleteEventArgs
---@return void
function LoadAssetBundleBytesCompleteEventHandler:Invoke(args) end
---@public
---@param args LoadAssetBundleBytesCompleteEventArgs
---@param callback AsyncCallback
---@param object Object
---@return IAsyncResult
function LoadAssetBundleBytesCompleteEventHandler:BeginInvoke(args, callback, object) end
---@public
---@param result IAsyncResult
---@return void
function LoadAssetBundleBytesCompleteEventHandler:EndInvoke(result) end
