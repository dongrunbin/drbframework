﻿---@class CheckVersionProcedure : Procedure
---@public
---@param userData Object
---@return void
function CheckVersionProcedure:OnEnter(userData) end
