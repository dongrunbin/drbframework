﻿---@class DataTableParser
---@public
---@return IEnumerator
function DataTableParser:GetEnumerator() end
---@public
---@param data Byte[]
---@return void
function DataTableParser:Parse(data) end
---@public
---@return void
function DataTableParser:Reset() end
