﻿---@class LoadResourceFailArgs : EventArgs
---@field public AssetPath string
---@field public AssetName string
---@field public Error string
