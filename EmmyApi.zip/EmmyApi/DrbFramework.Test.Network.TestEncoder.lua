﻿---@class TestEncoder
---@public
---@param channel INetworkChannel
---@param inData Object
---@param outData Stream
---@return void
function TestEncoder:Encode(channel, inData, outData) end
