﻿---@class IDebugWindow
---@public
---@return void
function IDebugWindow:OnInit() end
---@public
---@return void
function IDebugWindow:OnShow() end
---@public
---@return void
function IDebugWindow:OnHide() end
---@public
---@return void
function IDebugWindow:OnUpdate() end
---@public
---@return void
function IDebugWindow:OnDestroy() end
