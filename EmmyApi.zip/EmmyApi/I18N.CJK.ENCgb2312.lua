﻿---@class ENCgb2312 : CP936
