﻿---@class IDataTableSystem
