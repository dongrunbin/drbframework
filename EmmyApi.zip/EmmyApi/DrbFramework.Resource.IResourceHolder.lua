﻿---@class IResourceHolder
---@field public AssetCount number
---@field public AssetBundleCount number
---@public
---@param assetName string
---@return bool
function IResourceHolder:HasAsset(assetName) end
---@public
---@param assetName string
---@return Object
function IResourceHolder:GetAsset(assetName) end
---@public
---@param assetName string
---@param asset Object
---@return void
function IResourceHolder:AddAsset(assetName, asset) end
---@public
---@param assetName string
---@return void
function IResourceHolder:RemoveAsset(assetName) end
---@public
---@param assetBundlePath string
---@return bool
function IResourceHolder:HasAssetBundle(assetBundlePath) end
---@public
---@param assetBundlePath string
---@return Object
function IResourceHolder:GetAssetBundle(assetBundlePath) end
---@public
---@param assetBundlePath string
---@param assetBundle Object
---@return void
function IResourceHolder:AddAssetBundle(assetBundlePath, assetBundle) end
---@public
---@param assetBundlePath string
---@return void
function IResourceHolder:RemoveAssetBundle(assetBundlePath) end
