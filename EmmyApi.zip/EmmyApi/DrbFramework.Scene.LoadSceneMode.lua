﻿---@class LoadSceneMode : Enum
---@field public value__ number
---@field public Single number
---@field public Additive number
