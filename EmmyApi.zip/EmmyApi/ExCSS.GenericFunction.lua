﻿---@class GenericFunction : Term
---@field public Name string
---@field public Arguments TermList
---@public
---@return string
function GenericFunction:ToString() end
