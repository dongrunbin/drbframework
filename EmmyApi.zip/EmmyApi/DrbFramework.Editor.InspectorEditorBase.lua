﻿---@class InspectorEditorBase : Editor
---@public
---@return void
function InspectorEditorBase:OnInspectorGUI() end
