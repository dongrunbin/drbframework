﻿---@class ParametrizedNode : AttributedNode
---@field public Name string
---@field public Parameters List`1
