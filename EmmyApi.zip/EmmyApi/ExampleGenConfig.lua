﻿---@class ExampleGenConfig
---@field public LuaCallCSharp List`1
---@field public CSharpCallLua List`1
---@field public BlackList List`1
