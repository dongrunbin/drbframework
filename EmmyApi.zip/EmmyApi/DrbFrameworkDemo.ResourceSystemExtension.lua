﻿---@class ResourceSystemExtension
---@public
---@param resourceSystem IResourceSystem
---@param assetPath string
---@param assetName string
---@return Object
function ResourceSystemExtension.LoadAsset(resourceSystem, assetPath, assetName) end
