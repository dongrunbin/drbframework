﻿---@class DbcsConvert
---@field public n2u Byte[]
---@field public u2n Byte[]
