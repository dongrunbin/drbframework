﻿---@class BreakPointDownloader : DownloaderComponent
---@public
---@param downloadUri string
---@param savePath string
---@param userData Object
---@param timeout number
---@return void
function BreakPointDownloader:Download(downloadUri, savePath, userData, timeout) end
---@public
---@return void
function BreakPointDownloader:Shutdown() end
