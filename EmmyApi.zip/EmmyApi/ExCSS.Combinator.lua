﻿---@class Combinator : Enum
---@field public value__ number
---@field public Child number
---@field public Descendent number
---@field public AdjacentSibling number
---@field public Sibling number
---@field public Namespace number
