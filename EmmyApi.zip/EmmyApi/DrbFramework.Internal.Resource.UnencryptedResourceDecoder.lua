﻿---@class UnencryptedResourceDecoder
---@public
---@param data Byte[]
---@return Object
function UnencryptedResourceDecoder:DecodeAssetBundle(data) end
