﻿---@class ISupportsSelector
---@field public Selector BaseSelector
