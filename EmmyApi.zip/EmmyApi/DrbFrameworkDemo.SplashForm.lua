﻿---@class SplashForm : UguiForm
---@public
---@return void
function SplashForm:OnOpen() end
