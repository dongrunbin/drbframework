﻿---@class NthOfTypeSelector : NthChildSelector
---@public
---@param friendlyFormat bool
---@param indentation number
---@return string
function NthOfTypeSelector:ToString(friendlyFormat, indentation) end
