﻿---@class SystemInformationWindow
---@public
---@return void
function SystemInformationWindow:OnInit() end
---@public
---@return void
function SystemInformationWindow:OnHide() end
---@public
---@return void
function SystemInformationWindow:OnShow() end
---@public
---@return void
function SystemInformationWindow:OnUpdate() end
---@public
---@return void
function SystemInformationWindow:OnDestroy() end
