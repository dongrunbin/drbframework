﻿---@class INetworkEncoder
---@public
---@param channel INetworkChannel
---@param inData Object
---@param outData Stream
---@return void
function INetworkEncoder:Encode(channel, inData, outData) end
