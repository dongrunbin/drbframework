﻿---@class Profiler : DebugFormBase
