﻿---@class Foo1Child : Foo1Parent
