﻿---@class IResourceLoader
---@field public OnLoadAssetComplete LoadAssetCompleteEventHandler
---@field public OnLoadAssetBundleBytesComplete LoadAssetBundleBytesCompleteEventHandler
---@public
---@param filePath string
---@param mode number
---@return Byte[]
function IResourceLoader:LoadFile(filePath, mode) end
---@public
---@param assetBundlePath string
---@param mode number
---@return Byte[]
function IResourceLoader:LoadAssetBundleBytes(assetBundlePath, mode) end
---@public
---@param assetBundle Object
---@param assetName string
---@param mode number
---@return Object
function IResourceLoader:LoadAssetFromAssetBundle(assetBundle, assetName, mode) end
---@public
---@param assetPath string
---@param mode number
---@return Object
function IResourceLoader:LoadAsset(assetPath, mode) end
---@public
---@param assetBundlePath string
---@param mode number
---@return void
function IResourceLoader:LoadAssetBundleBytesAsync(assetBundlePath, mode) end
---@public
---@param assetBundle Object
---@param assetName string
---@param mode number
---@return void
function IResourceLoader:LoadAssetFromAssetBundleAsync(assetBundle, assetName, mode) end
---@public
---@param assetPath string
---@param mode number
---@return void
function IResourceLoader:LoadAssetAsync(assetPath, mode) end
---@public
---@param assetBundle Object
---@param mode number
---@return void
function IResourceLoader:ReleaseAssetBundle(assetBundle, mode) end
---@public
---@param asset Object
---@param mode number
---@return void
function IResourceLoader:ReleaseAsset(asset, mode) end
