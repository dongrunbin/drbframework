﻿---@class LoadAssetBundleCompleteEventArgs : EventArgs
---@field public AssetBundlePath string
---@field public AssetBundle Object
---@field public HasError bool
---@field public Error string
---@field public UserData Object
