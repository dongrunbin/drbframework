﻿---@class CP54936 : GB18030Encoding
