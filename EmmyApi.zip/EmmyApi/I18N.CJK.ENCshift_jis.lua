﻿---@class ENCshift_jis : CP932
