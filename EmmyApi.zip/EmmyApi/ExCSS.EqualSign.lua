﻿---@class EqualSign : Term
---@public
---@return string
function EqualSign:ToString() end
