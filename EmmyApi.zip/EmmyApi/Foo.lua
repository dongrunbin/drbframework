﻿---@class Foo
