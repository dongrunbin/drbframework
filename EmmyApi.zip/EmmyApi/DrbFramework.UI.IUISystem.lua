﻿---@class IUISystem
---@field public UIRoot Object
---@public
---@param assetPath string
---@param mode number
---@return IUIForm
function IUISystem:OpenForm(assetPath, mode) end
---@public
---@param assetPath string
---@param assetName string
---@param mode number
---@return IUIForm
function IUISystem:OpenForm(assetPath, assetName, mode) end
---@public
---@param assetPath string
---@param assetName string
---@param onOpened UIFormOpenedEventHandler
---@param userData Object
---@return void
function IUISystem:OpenFormAsync(assetPath, assetName, onOpened, userData) end
---@public
---@param form IUIForm
---@return void
function IUISystem:OpenForm(form) end
---@public
---@param form IUIForm
---@return void
function IUISystem:CloseForm(form) end
---@public
---@param form IUIForm
---@return void
function IUISystem:DestroyForm(form) end
