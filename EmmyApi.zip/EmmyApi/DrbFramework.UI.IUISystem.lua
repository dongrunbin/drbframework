﻿---@class IUISystem
---@field public UIRoot Object
---@field public FormCount number
---@field public ClosedFormCount number
---@field public ShowingFormCount number
---@public
---@param formName string
---@param formAsset Object
---@return IUIForm
function IUISystem:OpenForm(formName, formAsset) end
---@public
---@param form IUIForm
---@return void
function IUISystem:OpenForm(form) end
---@public
---@param form IUIForm
---@return void
function IUISystem:CloseForm(form) end
---@public
---@return void
function IUISystem:CloseAllForm() end
---@public
---@param form IUIForm
---@return void
function IUISystem:DestroyForm(form) end
---@public
---@return void
function IUISystem:DestroyAllForm() end
