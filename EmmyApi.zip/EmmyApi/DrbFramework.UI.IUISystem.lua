﻿---@class IUISystem
