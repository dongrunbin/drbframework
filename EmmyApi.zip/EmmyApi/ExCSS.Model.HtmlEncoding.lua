﻿---@class HtmlEncoding
