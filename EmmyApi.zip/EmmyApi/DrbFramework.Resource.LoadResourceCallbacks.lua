﻿---@class LoadResourceCallbacks
---@field public SuccessCallback LoadResourceSuccessCallback
---@field public FailCallback LoadResourceFailCallback
---@field public UserData Object
