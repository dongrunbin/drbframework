﻿---@class ParameterModifiers : Enum
---@field public value__ number
---@field public None number
---@field public In number
---@field public Out number
---@field public Ref number
---@field public Params number
---@field public Optional number
