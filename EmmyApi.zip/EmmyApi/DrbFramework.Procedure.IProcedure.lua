﻿---@class IProcedure
