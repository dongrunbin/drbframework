﻿---@class FooExtension
---@public
---@param a Foo1Parent
---@return void
function FooExtension.PlainExtension(a) end
