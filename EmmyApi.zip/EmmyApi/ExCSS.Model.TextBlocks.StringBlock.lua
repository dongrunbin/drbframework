﻿---@class StringBlock : Block
---@public
---@return string
function StringBlock:ToString() end
