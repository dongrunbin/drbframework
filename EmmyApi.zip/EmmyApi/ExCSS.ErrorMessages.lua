﻿---@class ErrorMessages
