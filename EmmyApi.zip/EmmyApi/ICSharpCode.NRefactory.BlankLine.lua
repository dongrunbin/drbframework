﻿---@class BlankLine : AbstractSpecial
---@public
---@param visitor ISpecialVisitor
---@param data Object
---@return Object
function BlankLine:AcceptVisitor(visitor, data) end
