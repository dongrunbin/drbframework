﻿---@class AssemblyValidationRule : Attribute
---@field public Priority number
---@field public Platform number
