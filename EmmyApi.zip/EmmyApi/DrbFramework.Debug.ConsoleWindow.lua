﻿---@class ConsoleWindow
---@public
---@return void
function ConsoleWindow:OnInit() end
---@public
---@return void
function ConsoleWindow:OnShow() end
---@public
---@return void
function ConsoleWindow:OnHide() end
---@public
---@return void
function ConsoleWindow:OnUpdate() end
---@public
---@return void
function ConsoleWindow:OnDestroy() end
