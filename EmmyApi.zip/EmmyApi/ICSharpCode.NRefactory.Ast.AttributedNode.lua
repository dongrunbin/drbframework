﻿---@class AttributedNode : AbstractNode
---@field public Attributes List`1
---@field public Modifier number
