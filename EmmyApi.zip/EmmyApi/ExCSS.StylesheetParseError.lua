﻿---@class StylesheetParseError
---@field public ParserError number
---@field public Line number
---@field public Column number
---@field public Message string
---@public
---@return string
function StylesheetParseError:ToString() end
