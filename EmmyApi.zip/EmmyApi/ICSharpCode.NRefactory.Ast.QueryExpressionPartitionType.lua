﻿---@class QueryExpressionPartitionType : Enum
---@field public value__ number
---@field public Take number
---@field public TakeWhile number
---@field public Skip number
---@field public SkipWhile number
