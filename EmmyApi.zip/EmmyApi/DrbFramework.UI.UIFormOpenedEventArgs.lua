﻿---@class UIFormOpenedEventArgs : EventArgs
---@field public UIForm IUIForm
---@field public Error string
---@field public UserData Object
