﻿---@class ConsoleLog : MonoBehaviour
---@public
---@param message string
---@param traceStack string
---@param logType number
---@return void
function ConsoleLog:SetLog(message, traceStack, logType) end
