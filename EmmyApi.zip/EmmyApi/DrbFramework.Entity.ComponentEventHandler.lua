﻿---@class ComponentEventHandler : MulticastDelegate
---@public
---@param entity IEntity
---@param component IComponent
---@return void
function ComponentEventHandler:Invoke(entity, component) end
---@public
---@param entity IEntity
---@param component IComponent
---@param callback AsyncCallback
---@param object Object
---@return IAsyncResult
function ComponentEventHandler:BeginInvoke(entity, component, callback, object) end
---@public
---@param result IAsyncResult
---@return void
function ComponentEventHandler:EndInvoke(result) end
