﻿---@class NthChildSelector : BaseSelector
---@field public Step number
---@field public Offset number
---@public
---@param friendlyFormat bool
---@param indentation number
---@return string
function NthChildSelector:ToString(friendlyFormat, indentation) end
