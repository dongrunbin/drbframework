﻿---@class Adler32
