﻿---@class IDebugSystem
---@field public CurrentForm IDebugForm
---@public
---@param formName string
---@return IDebugForm
function IDebugSystem:GetDebugForm(formName) end
---@public
---@param type Type
---@return IDebugForm
function IDebugSystem:GetDebugForm(type) end
---@public
---@return IDebugForm[]
function IDebugSystem:GetAllDebugForms() end
---@public
---@return String[]
function IDebugSystem:GetAllDebugFormNames() end
---@public
---@param type Type
---@return void
function IDebugSystem:OpenDebugForm(type) end
---@public
---@param formName string
---@return void
function IDebugSystem:OpenDebugForm(formName) end
---@public
---@return void
function IDebugSystem:CloseCurrentForm() end
---@public
---@param form IDebugForm
---@return void
function IDebugSystem:RegisterDebugForm(form) end
---@public
---@return void
function IDebugSystem:Draw() end
