﻿---@class IDebugSystem
