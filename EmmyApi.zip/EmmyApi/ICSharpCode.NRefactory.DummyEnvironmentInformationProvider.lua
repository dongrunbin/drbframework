﻿---@class DummyEnvironmentInformationProvider
---@public
---@param reflectionTypeName string
---@param typeParameterCount number
---@param fieldName string
---@return bool
function DummyEnvironmentInformationProvider:HasField(reflectionTypeName, typeParameterCount, fieldName) end
