﻿---@class EditorGuiEnabler
---@public
---@return void
function EditorGuiEnabler:Dispose() end
