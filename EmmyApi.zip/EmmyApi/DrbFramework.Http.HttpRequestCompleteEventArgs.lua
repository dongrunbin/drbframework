﻿---@class HttpRequestCompleteEventArgs : EventArgs
---@field public HasError bool
---@field public Error string
---@field public Data Byte[]
