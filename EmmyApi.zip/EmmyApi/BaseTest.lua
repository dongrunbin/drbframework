﻿---@class BaseTest : BaseTestBase`1
---@public
---@param p number
---@return void
function BaseTest:Foo(p) end
---@public
---@param p number
---@return void
function BaseTest:Proxy(p) end
---@public
---@return string
function BaseTest:ToString() end
