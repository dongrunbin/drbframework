﻿---@class UIForm : MonoBehaviour
---@field public Depth number
---@field public FormName string
---@field public IsShow bool
---@public
---@return void
function UIForm:OnInit() end
---@public
---@return void
function UIForm:OnOpen() end
---@public
---@param elapseSeconds number
---@param realElapseSeconds number
---@return void
function UIForm:OnUpdate(elapseSeconds, realElapseSeconds) end
---@public
---@return void
function UIForm:OnClose() end
---@public
---@return void
function UIForm:OnBeforeDestroy() end
---@public
---@return void
function UIForm:OnCover() end
---@public
---@return void
function UIForm:OnFocus() end
