﻿---@class UIForm : MonoBehaviour
---@public
---@return void
function UIForm:OnInit() end
---@public
---@return void
function UIForm:OnShow() end
---@public
---@return void
function UIForm:OnHide() end
---@public
---@return void
function UIForm:OnBeforeDestroy() end
