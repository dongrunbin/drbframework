﻿---@class ConditionalRule : AggregateRule
---@field public Condition string
