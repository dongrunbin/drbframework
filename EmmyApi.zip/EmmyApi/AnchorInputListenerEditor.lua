﻿---@class AnchorInputListenerEditor : Editor
---@public
---@return void
function AnchorInputListenerEditor:OnInspectorGUI() end
