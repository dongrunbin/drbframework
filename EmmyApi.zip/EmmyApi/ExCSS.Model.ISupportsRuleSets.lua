﻿---@class ISupportsRuleSets
---@field public RuleSets List`1
