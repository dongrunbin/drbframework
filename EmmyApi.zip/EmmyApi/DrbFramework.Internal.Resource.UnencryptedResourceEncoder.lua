﻿---@class UnencryptedResourceEncoder
---@public
---@param filePath string
---@param assetBundleData Byte[]
---@return Byte[]
function UnencryptedResourceEncoder:EncodeAssetBundle(filePath, assetBundleData) end
