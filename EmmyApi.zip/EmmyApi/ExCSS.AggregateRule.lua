﻿---@class AggregateRule : RuleSet
---@field public RuleSets List`1
