﻿---@class DrbException : Exception
