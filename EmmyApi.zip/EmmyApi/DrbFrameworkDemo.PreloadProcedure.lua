﻿---@class PreloadProcedure : Procedure
---@public
---@param userData Object
---@return void
function PreloadProcedure:OnEnter(userData) end
