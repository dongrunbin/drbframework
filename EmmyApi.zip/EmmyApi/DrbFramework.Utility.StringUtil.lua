﻿---@class StringUtil
---@public
---@param path1 string
---@param path2 string
---@return string
function StringUtil.CombinePath(path1, path2) end
---@public
---@param str string
---@return string
function StringUtil.GetFileProtocolPath(str) end
