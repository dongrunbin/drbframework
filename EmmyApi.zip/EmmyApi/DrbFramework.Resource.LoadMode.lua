﻿---@class LoadMode : Enum
---@field public value__ number
---@field public Persistent number
---@field public ReadOnly number
---@field public Internal number
---@field public Editor number
