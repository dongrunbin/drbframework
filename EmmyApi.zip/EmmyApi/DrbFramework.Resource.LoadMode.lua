﻿---@class LoadMode : Enum
---@field public value__ number
---@field public Editor number
---@field public Resource number
---@field public AssetBundle number
---@field public Download number
