﻿---@class Whitespace : Term
---@public
---@return string
function Whitespace:ToString() end
