﻿---@class SceneInfo : DebugFormBase
