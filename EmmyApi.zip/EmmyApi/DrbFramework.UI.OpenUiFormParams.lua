﻿---@class OpenUiFormParams
---@field public OnOpened UIFormOpenedEventHandler
---@field public UserData Object
