﻿---@class SymbolBlock : Block
---@public
---@return string
function SymbolBlock:ToString() end
