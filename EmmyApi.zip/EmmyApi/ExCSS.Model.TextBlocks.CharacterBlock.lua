﻿---@class CharacterBlock : Block
