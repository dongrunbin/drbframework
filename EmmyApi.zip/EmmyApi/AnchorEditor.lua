﻿---@class AnchorEditor : Editor
---@public
---@return void
function AnchorEditor:OnInspectorGUI() end
