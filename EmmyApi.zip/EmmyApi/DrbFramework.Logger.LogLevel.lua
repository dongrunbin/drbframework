﻿---@class LogLevel : Enum
---@field public value__ number
---@field public Trace number
---@field public Debug number
---@field public Info number
---@field public Warn number
---@field public Error number
---@field public Fatal number
