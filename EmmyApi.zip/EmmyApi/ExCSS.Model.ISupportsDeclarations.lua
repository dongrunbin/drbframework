﻿---@class ISupportsDeclarations
---@field public Declarations StyleDeclaration
