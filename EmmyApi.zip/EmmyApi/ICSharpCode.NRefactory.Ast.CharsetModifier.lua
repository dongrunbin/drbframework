﻿---@class CharsetModifier : Enum
---@field public value__ number
---@field public None number
---@field public Auto number
---@field public Unicode number
---@field public Ansi number
