﻿---@class Foo2Child : Foo2Parent
