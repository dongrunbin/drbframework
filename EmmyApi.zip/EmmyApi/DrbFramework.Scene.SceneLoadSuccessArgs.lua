﻿---@class SceneLoadSuccessArgs : EventArgs
---@field public SceneName string
---@field public Mode number
