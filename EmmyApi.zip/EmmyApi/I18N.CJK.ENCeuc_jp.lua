﻿---@class ENCeuc_jp : CP51932
