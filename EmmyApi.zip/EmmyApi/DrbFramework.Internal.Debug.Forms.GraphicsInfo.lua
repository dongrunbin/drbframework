﻿---@class GraphicsInfo : DebugFormBase
