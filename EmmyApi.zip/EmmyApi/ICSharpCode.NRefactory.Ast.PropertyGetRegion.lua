﻿---@class PropertyGetRegion : PropertyGetSetRegion
---@field public Null PropertyGetRegion
---@public
---@param visitor IAstVisitor
---@param data Object
---@return Object
function PropertyGetRegion:AcceptVisitor(visitor, data) end
---@public
---@return string
function PropertyGetRegion:ToString() end
