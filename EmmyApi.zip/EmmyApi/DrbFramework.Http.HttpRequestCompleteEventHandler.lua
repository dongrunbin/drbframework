﻿---@class HttpRequestCompleteEventHandler : MulticastDelegate
---@public
---@param sender Object
---@param args HttpRequestCompleteEventArgs
---@return void
function HttpRequestCompleteEventHandler:Invoke(sender, args) end
---@public
---@param sender Object
---@param args HttpRequestCompleteEventArgs
---@param callback AsyncCallback
---@param object Object
---@return IAsyncResult
function HttpRequestCompleteEventHandler:BeginInvoke(sender, args, callback, object) end
---@public
---@param result IAsyncResult
---@return void
function HttpRequestCompleteEventHandler:EndInvoke(result) end
