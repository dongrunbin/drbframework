﻿---@class ITimerSystem
---@public
---@param delay number
---@param interval number
---@param loop number
---@param onStart OnStartHandler
---@param onUpdate OnUpdateHandler
---@param onComplete OnCompleteHandler
---@return void
function ITimerSystem:RegisterTimer(delay, interval, loop, onStart, onUpdate, onComplete) end
---@public
---@param timer Timer
---@param isComplete bool
---@return void
function ITimerSystem:RemoveTimer(timer, isComplete) end
