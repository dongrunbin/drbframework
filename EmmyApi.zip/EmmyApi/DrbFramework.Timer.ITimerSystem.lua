﻿---@class ITimerSystem
---@public
---@param timer Timer
---@return void
function ITimerSystem:RegisterTimer(timer) end
---@public
---@param timer Timer
---@return void
function ITimerSystem:RemoveTimer(timer) end
