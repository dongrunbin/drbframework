﻿---@class ENCiso_2022_jp : CP50220
