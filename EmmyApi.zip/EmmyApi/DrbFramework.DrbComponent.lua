﻿---@class DrbComponent : MonoBehaviour
---@field public FrameRate number
---@field public TimeScale number
---@field public RunInBackground bool
---@field public SleepTimeout number
