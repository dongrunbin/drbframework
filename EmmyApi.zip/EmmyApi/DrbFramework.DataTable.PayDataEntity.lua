﻿---@class PayDataEntity
---@field public Id number
---@field public name string
---@field public iosCode string
---@field public money number
---@field public amount number
---@field public give number
---@field public isHot bool
---@field public icon string
---@field public type number
---@public
---@param row IDataRow
---@return void
function PayDataEntity:MakeEntity(row) end
