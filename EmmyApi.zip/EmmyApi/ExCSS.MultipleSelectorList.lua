﻿---@class MultipleSelectorList : SelectorList
---@public
---@param friendlyFormat bool
---@param indentation number
---@return string
function MultipleSelectorList:ToString(friendlyFormat, indentation) end
