﻿---@class SimpleSounderCreater
---@public
---@param soundRoot Object
---@return ISounder
function SimpleSounderCreater:CreateSounder(soundRoot) end
