﻿---@class SplashProcedure : Procedure
---@public
---@param userData Object
---@return void
function SplashProcedure:OnEnter(userData) end
---@public
---@return void
function SplashProcedure:OnLeave() end
