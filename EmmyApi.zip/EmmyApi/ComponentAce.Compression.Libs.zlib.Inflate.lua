﻿---@class Inflate
