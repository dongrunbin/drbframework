﻿---@class GenPathAttribute : Attribute
