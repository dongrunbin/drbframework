﻿---@class IResourceSystem
---@field public ReadOnlyPath string
---@field public PersistentPath string
---@field public InternalPath string
---@field public EditorPath string
---@field public LoadingAssetBundleCount number
---@field public LoadingAssetCount number
---@field public AssetCount number
---@field public AssetBundleCount number
---@public
---@param value LoadAssetBundleCompleteEventHandler
---@return void
function IResourceSystem:add_OnAssetBundleLoaded(value) end
---@public
---@param value LoadAssetBundleCompleteEventHandler
---@return void
function IResourceSystem:remove_OnAssetBundleLoaded(value) end
---@public
---@param value LoadAssetCompleteEventHandler
---@return void
function IResourceSystem:add_OnAssetLoaded(value) end
---@public
---@param value LoadAssetCompleteEventHandler
---@return void
function IResourceSystem:remove_OnAssetLoaded(value) end
---@public
---@param filePath string
---@param mode number
---@return Byte[]
function IResourceSystem:LoadFile(filePath, mode) end
---@public
---@param assetBundlePath string
---@param assetName string
---@param mode number
---@return Object
function IResourceSystem:LoadAssetFromAssetBundle(assetBundlePath, assetName, mode) end
---@public
---@param assetBundlePath string
---@param mode number
---@return Object
function IResourceSystem:LoadAssetBundle(assetBundlePath, mode) end
---@public
---@param assetPath string
---@param mode number
---@return Object
function IResourceSystem:LoadAsset(assetPath, mode) end
---@public
---@param assetPath string
---@param mode number
---@param onComplete LoadAssetCompleteEventHandler
---@param userData Object
---@return void
function IResourceSystem:LoadAssetAsync(assetPath, mode, onComplete, userData) end
---@public
---@param assetBundlePath string
---@param mode number
---@param onComplete LoadAssetBundleCompleteEventHandler
---@param userData Object
---@return void
function IResourceSystem:LoadAssetBundleAsync(assetBundlePath, mode, onComplete, userData) end
---@public
---@param assetBundlePath string
---@param assetName string
---@param mode number
---@param onComplete LoadAssetCompleteEventHandler
---@param userData Object
---@return void
function IResourceSystem:LoadAssetFromAssetBundleAsync(assetBundlePath, assetName, mode, onComplete, userData) end
---@public
---@param assetPath string
---@param mode number
---@return bool
function IResourceSystem:HasAsset(assetPath, mode) end
---@public
---@param assetBundlePath string
---@param assetName string
---@param mode number
---@return bool
function IResourceSystem:HasAsset(assetBundlePath, assetName, mode) end
---@public
---@param assetBundlePath string
---@param mode number
---@return bool
function IResourceSystem:HasAssetBundle(assetBundlePath, mode) end
---@public
---@param assetPath string
---@param mode number
---@return bool
function IResourceSystem:ReleaseAsset(assetPath, mode) end
---@public
---@param assetBundlePath string
---@param assetName string
---@param mode number
---@return bool
function IResourceSystem:ReleaseAsset(assetBundlePath, assetName, mode) end
---@public
---@param assetBundlePath string
---@param mode number
---@return bool
function IResourceSystem:ReleaseAssetBundle(assetBundlePath, mode) end
