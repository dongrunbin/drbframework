﻿---@class CP50220 : ISO2022JPEncoding
---@field public EncodingName string
