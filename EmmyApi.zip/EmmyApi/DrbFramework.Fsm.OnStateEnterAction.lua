﻿---@class OnStateEnterAction : MulticastDelegate
---@public
---@param fsm IFsm
---@param userData Object
---@return void
function OnStateEnterAction:Invoke(fsm, userData) end
---@public
---@param fsm IFsm
---@param userData Object
---@param callback AsyncCallback
---@param object Object
---@return IAsyncResult
function OnStateEnterAction:BeginInvoke(fsm, userData, callback, object) end
---@public
---@param result IAsyncResult
---@return void
function OnStateEnterAction:EndInvoke(result) end
