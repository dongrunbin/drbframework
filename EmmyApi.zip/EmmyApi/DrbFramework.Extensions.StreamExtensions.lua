﻿---@class StreamExtensions
---@public
---@param ms Stream
---@param isReverse bool
---@return number
function StreamExtensions.ReadShort(ms, isReverse) end
---@public
---@param ms Stream
---@param value number
---@param isReverse bool
---@return void
function StreamExtensions.WriteShort(ms, value, isReverse) end
---@public
---@param ms Stream
---@param isReverse bool
---@return number
function StreamExtensions.ReadUShort(ms, isReverse) end
---@public
---@param ms Stream
---@param value number
---@param isReverse bool
---@return void
function StreamExtensions.WriteUShort(ms, value, isReverse) end
---@public
---@param ms Stream
---@param isReverse bool
---@return number
function StreamExtensions.ReadInt(ms, isReverse) end
---@public
---@param ms Stream
---@param value number
---@param isReverse bool
---@return void
function StreamExtensions.WriteInt(ms, value, isReverse) end
---@public
---@param ms Stream
---@param isReverse bool
---@return number
function StreamExtensions.ReadUInt(ms, isReverse) end
---@public
---@param ms Stream
---@param value number
---@param isReverse bool
---@return void
function StreamExtensions.WriteUInt(ms, value, isReverse) end
---@public
---@param ms Stream
---@param isReverse bool
---@return number
function StreamExtensions.ReadLong(ms, isReverse) end
---@public
---@param ms Stream
---@param value number
---@param isReverse bool
---@return void
function StreamExtensions.WriteLong(ms, value, isReverse) end
---@public
---@param ms Stream
---@param isReverse bool
---@return number
function StreamExtensions.ReadULong(ms, isReverse) end
---@public
---@param ms Stream
---@param value number
---@param isReverse bool
---@return void
function StreamExtensions.WriteULong(ms, value, isReverse) end
---@public
---@param ms Stream
---@return number
function StreamExtensions.ReadFloat(ms) end
---@public
---@param ms Stream
---@param value number
---@return void
function StreamExtensions.WriteFloat(ms, value) end
---@public
---@param ms Stream
---@return number
function StreamExtensions.ReadDouble(ms) end
---@public
---@param ms Stream
---@param value number
---@return void
function StreamExtensions.WriteDouble(ms, value) end
---@public
---@param ms Stream
---@return bool
function StreamExtensions.ReadBool(ms) end
---@public
---@param ms Stream
---@param value bool
---@return void
function StreamExtensions.WriteBool(ms, value) end
---@public
---@param ms Stream
---@param isReverse bool
---@return string
function StreamExtensions.ReadUTF8String(ms, isReverse) end
---@public
---@param ms Stream
---@param str string
---@param isReverse bool
---@return void
function StreamExtensions.WriteUTF8String(ms, str, isReverse) end
---@public
---@param ms Stream
---@param data Byte[]
---@param isReverse bool
---@return void
function StreamExtensions.WriteBytes(ms, data, isReverse) end
---@public
---@param ms Stream
---@param isReverse bool
---@return Byte[]
function StreamExtensions.ReadBytes(ms, isReverse) end
