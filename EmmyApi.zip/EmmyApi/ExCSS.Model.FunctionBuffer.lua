﻿---@class FunctionBuffer
---@field public TermList List`1
---@field public Term Term
---@public
---@return void
function FunctionBuffer:Include() end
---@public
---@return Term
function FunctionBuffer:Done() end
