﻿---@class HotfixCalc
---@public
---@param a number
---@param b number
---@return number
function HotfixCalc:Add(a, b) end
---@public
---@param a Vector3
---@param b Vector3
---@return Vector3
function HotfixCalc:Add(a, b) end
---@public
---@param a number
---@param b Double&
---@param c String&
---@return number
function HotfixCalc:TestOut(a, b, c) end
---@public
---@param a number
---@param b Double&
---@param c String&
---@param go GameObject
---@return number
function HotfixCalc:TestOut(a, b, c, go) end
