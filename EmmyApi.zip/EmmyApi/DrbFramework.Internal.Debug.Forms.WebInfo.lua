﻿---@class WebInfo : DebugFormBase
