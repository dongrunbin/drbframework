﻿---@class LoadAssetCompleteEventArgs : EventArgs
---@field public AssetName string
---@field public Asset Object
---@field public HasError bool
---@field public Error string
---@field public UserData Object
