﻿---@class InfTree
