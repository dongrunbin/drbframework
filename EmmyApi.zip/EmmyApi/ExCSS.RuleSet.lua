﻿---@class RuleSet
---@field public RuleType number
---@public
---@param friendlyFormat bool
---@param indentation number
---@return string
function RuleSet:ToString(friendlyFormat, indentation) end
