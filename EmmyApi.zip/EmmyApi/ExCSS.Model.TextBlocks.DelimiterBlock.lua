﻿---@class DelimiterBlock : CharacterBlock
---@public
---@return string
function DelimiterBlock:ToString() end
