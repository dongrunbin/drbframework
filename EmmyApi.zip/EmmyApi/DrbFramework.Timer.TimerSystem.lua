﻿---@class TimerSystem
---@field public Priority number
---@public
---@return void
function TimerSystem:Shutdown() end
---@public
---@param elapseSeconds number
---@param realElapseSeconds number
---@return void
function TimerSystem:Update(elapseSeconds, realElapseSeconds) end
---@public
---@param delay number
---@param interval number
---@param loop number
---@param onStart OnStartHandler
---@param onUpdate OnUpdateHandler
---@param onComplete OnCompleteHandler
---@return void
function TimerSystem:RegisterTimer(delay, interval, loop, onStart, onUpdate, onComplete) end
---@public
---@param timer Timer
---@param isComplete bool
---@return void
function TimerSystem:RemoveTimer(timer, isComplete) end
