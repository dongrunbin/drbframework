﻿---@class LocalizerComponent : MonoBehaviour
---@field public Key string
---@field public Value string
