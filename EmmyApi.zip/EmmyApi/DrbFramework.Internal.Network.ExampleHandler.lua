﻿---@class ExampleHandler
---@public
---@param channel INetworkChannel
---@param sentLength number
---@return void
function ExampleHandler:OnChannelSent(channel, sentLength) end
---@public
---@param channel INetworkChannel
---@param obj Object
---@return void
function ExampleHandler:OnChannelReceived(channel, obj) end
---@public
---@param channel INetworkChannel
---@return void
function ExampleHandler:OnClosed(channel) end
---@public
---@param channel INetworkChannel
---@return void
function ExampleHandler:OnConnected(channel) end
---@public
---@param channel INetworkChannel
---@param exception Exception
---@return void
function ExampleHandler:OnExceptionCaught(channel, exception) end
---@public
---@param elapseSeconds number
---@param realElapseSeconds number
---@return void
function ExampleHandler:Update(elapseSeconds, realElapseSeconds) end
