﻿---@class LogRedirect
