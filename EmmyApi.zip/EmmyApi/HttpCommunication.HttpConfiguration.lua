﻿---@class HttpConfiguration
