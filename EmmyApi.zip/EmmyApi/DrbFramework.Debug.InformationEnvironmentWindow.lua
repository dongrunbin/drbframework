﻿---@class InformationEnvironmentWindow
---@public
---@return void
function InformationEnvironmentWindow:OnInit() end
---@public
---@return void
function InformationEnvironmentWindow:OnHide() end
---@public
---@return void
function InformationEnvironmentWindow:OnShow() end
---@public
---@return void
function InformationEnvironmentWindow:OnUpdate() end
---@public
---@return void
function InformationEnvironmentWindow:OnDestroy() end
