﻿---@class IDataRow
---@public
---@param fieldName string
---@return string
function IDataRow:GetFieldValue(fieldName) end
---@public
---@param index number
---@return string
function IDataRow:GetFieldValue(index) end
