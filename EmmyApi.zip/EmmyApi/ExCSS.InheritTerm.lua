﻿---@class InheritTerm : Term
---@public
---@return string
function InheritTerm:ToString() end
