﻿---@class SceneSystem
---@field public OnSceneLoaded SceneLoadedHandler
---@field public OnSceneUnloaded SceneUnloadedHandler
---@field public Priority number
---@field public CurrentScenes String[]
---@public
---@return void
function SceneSystem:Shutdown() end
---@public
---@param elapseSeconds number
---@param realElapseSeconds number
---@return void
function SceneSystem:Update(elapseSeconds, realElapseSeconds) end
---@public
---@param sceneName string
---@return void
function SceneSystem:LoadScene(sceneName) end
---@public
---@param sceneName string
---@return void
function SceneSystem:AddScene(sceneName) end
---@public
---@param sceneName string
---@return void
function SceneSystem:UnloadScene(sceneName) end
---@public
---@param sceneName string
---@return void
function SceneSystem:LoadSceneAsync(sceneName) end
---@public
---@param sceneName string
---@return void
function SceneSystem:AddSceneAsync(sceneName) end
---@public
---@param sceneName string
---@return void
function SceneSystem:UnloadSceneAsync(sceneName) end
