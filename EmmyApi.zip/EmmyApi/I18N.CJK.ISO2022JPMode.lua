﻿---@class ISO2022JPMode : Enum
---@field public value__ number
---@field public ASCII number
---@field public JISX0208 number
---@field public JISX0201 number
