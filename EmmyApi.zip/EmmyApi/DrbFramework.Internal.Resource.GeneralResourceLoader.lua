﻿---@class GeneralResourceLoader : ResourceLoaderComponent
---@field public OnLoadAssetComplete LoadAssetCompleteEventHandler
---@field public OnLoadAssetBundleBytesComplete LoadAssetBundleBytesCompleteEventHandler
---@public
---@param assetPath string
---@param mode number
---@return Object
function GeneralResourceLoader:LoadAsset(assetPath, mode) end
---@public
---@param assetPath string
---@param mode number
---@return void
function GeneralResourceLoader:LoadAssetAsync(assetPath, mode) end
---@public
---@param assetBundlePath string
---@param mode number
---@return Byte[]
function GeneralResourceLoader:LoadAssetBundleBytes(assetBundlePath, mode) end
---@public
---@param assetBundlePath string
---@param mode number
---@return void
function GeneralResourceLoader:LoadAssetBundleBytesAsync(assetBundlePath, mode) end
---@public
---@param assetBundle Object
---@param assetName string
---@param mode number
---@return Object
function GeneralResourceLoader:LoadAssetFromAssetBundle(assetBundle, assetName, mode) end
---@public
---@param assetBundle Object
---@param assetName string
---@param mode number
---@return void
function GeneralResourceLoader:LoadAssetFromAssetBundleAsync(assetBundle, assetName, mode) end
---@public
---@param filePath string
---@param mode number
---@return Byte[]
function GeneralResourceLoader:LoadFile(filePath, mode) end
---@public
---@param assetBundle Object
---@param mode number
---@return void
function GeneralResourceLoader:ReleaseAssetBundle(assetBundle, mode) end
---@public
---@param asset Object
---@param mode number
---@return void
function GeneralResourceLoader:ReleaseAsset(asset, mode) end
