﻿---@class ResourceSystem
---@field public Priority number
---@field public ReadOnlyPath string
---@field public PersistentPath string
---@field public InternalPath string
---@field public EditorPath string
---@field public LoadingAssetBundleCount number
---@field public LoadingAssetCount number
---@field public AssetCount number
---@field public AssetBundleCount number
---@public
---@return void
function ResourceSystem:Shutdown() end
---@public
---@param elapseSeconds number
---@param realElapseSeconds number
---@return void
function ResourceSystem:Update(elapseSeconds, realElapseSeconds) end
---@public
---@param filePath string
---@param mode number
---@return Byte[]
function ResourceSystem:LoadFile(filePath, mode) end
---@public
---@param assetBundlePath string
---@param mode number
---@return Object
function ResourceSystem:LoadAssetBundle(assetBundlePath, mode) end
---@public
---@param assetBundlePath string
---@param mode number
---@param onComplete LoadAssetBundleCompleteEventHandler
---@param userData Object
---@return void
function ResourceSystem:LoadAssetBundleAsync(assetBundlePath, mode, onComplete, userData) end
---@public
---@param assetBundlePath string
---@return bool
function ResourceSystem:IsLoadingAssetBundle(assetBundlePath) end
---@public
---@param assetBundlePath string
---@param assetName string
---@return bool
function ResourceSystem:IsLoadingAsset(assetBundlePath, assetName) end
---@public
---@param assetBundlePath string
---@param assetName string
---@param mode number
---@return Object
function ResourceSystem:LoadAssetFromAssetBundle(assetBundlePath, assetName, mode) end
---@public
---@param assetBundlePath string
---@param assetName string
---@param mode number
---@param onComplete LoadAssetCompleteEventHandler
---@param userData Object
---@return void
function ResourceSystem:LoadAssetFromAssetBundleAsync(assetBundlePath, assetName, mode, onComplete, userData) end
---@public
---@param assetPath string
---@param mode number
---@return Object
function ResourceSystem:LoadAsset(assetPath, mode) end
---@public
---@param assetPath string
---@param mode number
---@param onComplete LoadAssetCompleteEventHandler
---@param userData Object
---@return void
function ResourceSystem:LoadAssetAsync(assetPath, mode, onComplete, userData) end
---@public
---@param assetPath string
---@param mode number
---@return bool
function ResourceSystem:HasAsset(assetPath, mode) end
---@public
---@param assetBundlePath string
---@param assetName string
---@param mode number
---@return bool
function ResourceSystem:HasAsset(assetBundlePath, assetName, mode) end
---@public
---@param assetBundlePath string
---@param mode number
---@return bool
function ResourceSystem:HasAssetBundle(assetBundlePath, mode) end
---@public
---@param assetPath string
---@param mode number
---@return bool
function ResourceSystem:ReleaseAsset(assetPath, mode) end
---@public
---@param assetBundlePath string
---@param assetName string
---@param mode number
---@return bool
function ResourceSystem:ReleaseAsset(assetBundlePath, assetName, mode) end
---@public
---@param assetBundlePath string
---@param mode number
---@return bool
function ResourceSystem:ReleaseAssetBundle(assetBundlePath, mode) end
