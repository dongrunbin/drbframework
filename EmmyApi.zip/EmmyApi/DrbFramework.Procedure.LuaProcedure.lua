﻿---@class LuaProcedure : Procedure
