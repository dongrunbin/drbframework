﻿---@class LuaProcedure : FsmLuaState
