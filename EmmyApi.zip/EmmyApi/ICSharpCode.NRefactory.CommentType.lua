﻿---@class CommentType : Enum
---@field public value__ number
---@field public Block number
---@field public SingleLine number
---@field public Documentation number
