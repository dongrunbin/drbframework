﻿---@class QueryExpressionOrderingDirection : Enum
---@field public value__ number
---@field public None number
---@field public Ascending number
---@field public Descending number
