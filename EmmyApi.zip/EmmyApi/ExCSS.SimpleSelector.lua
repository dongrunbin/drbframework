﻿---@class SimpleSelector : BaseSelector
---@public
---@param friendlyFormat bool
---@param indentation number
---@return string
function SimpleSelector:ToString(friendlyFormat, indentation) end
