﻿---@class NumericBlock : Block
---@field public Value number
---@public
---@return string
function NumericBlock:ToString() end
