﻿---@class ILocalizer
---@field public Key string
---@field public Value string
