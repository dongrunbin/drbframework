﻿---@class ZStreamException : IOException
