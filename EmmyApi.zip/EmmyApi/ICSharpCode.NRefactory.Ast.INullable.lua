﻿---@class INullable
---@field public IsNull bool
