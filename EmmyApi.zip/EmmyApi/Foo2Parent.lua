﻿---@class Foo2Parent
