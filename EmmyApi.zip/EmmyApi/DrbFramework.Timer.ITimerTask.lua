﻿---@class ITimerTask
---@public
---@return void
function ITimerTask:Run() end
