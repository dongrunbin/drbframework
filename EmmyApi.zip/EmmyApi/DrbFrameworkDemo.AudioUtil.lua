﻿---@class AudioUtil
---@public
---@param assetBundlePath string
---@param assetName string
---@param mode number
---@return void
function AudioUtil.PlayBGM(assetBundlePath, assetName, mode) end
