﻿---@class IToString
---@public
---@param friendlyFormat bool
---@param indentation number
---@return string
function IToString:ToString(friendlyFormat, indentation) end
