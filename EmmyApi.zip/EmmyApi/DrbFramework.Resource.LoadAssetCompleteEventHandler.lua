﻿---@class LoadAssetCompleteEventHandler : MulticastDelegate
---@public
---@param args LoadAssetCompleteEventArgs
---@return void
function LoadAssetCompleteEventHandler:Invoke(args) end
---@public
---@param args LoadAssetCompleteEventArgs
---@param callback AsyncCallback
---@param object Object
---@return IAsyncResult
function LoadAssetCompleteEventHandler:BeginInvoke(args, callback, object) end
---@public
---@param result IAsyncResult
---@return void
function LoadAssetCompleteEventHandler:EndInvoke(result) end
