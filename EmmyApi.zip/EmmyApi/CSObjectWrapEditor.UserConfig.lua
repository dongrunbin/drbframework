﻿---@class UserConfig : ValueType
---@field public LuaCallCSharp IEnumerable`1
---@field public CSharpCallLua IEnumerable`1
---@field public ReflectionUse IEnumerable`1
