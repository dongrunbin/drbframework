﻿---@class LoadAssetBundleBytesCompleteEventArgs : EventArgs
---@field public AssetBundlePath string
---@field public Data Byte[]
---@field public HasError bool
---@field public Error string
