﻿---@class XLuaTemplate : ValueType
---@field public name string
---@field public text string
