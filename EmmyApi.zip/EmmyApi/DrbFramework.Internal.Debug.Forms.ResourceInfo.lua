﻿---@class ResourceInfo : DebugFormBase
---@field public ResourceSystem IResourceSystem
