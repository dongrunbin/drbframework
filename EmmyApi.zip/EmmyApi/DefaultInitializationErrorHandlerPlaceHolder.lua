﻿---@class DefaultInitializationErrorHandlerPlaceHolder : VuforiaMonoBehaviour
