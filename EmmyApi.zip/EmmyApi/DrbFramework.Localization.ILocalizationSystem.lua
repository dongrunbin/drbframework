﻿---@class ILocalizationSystem
