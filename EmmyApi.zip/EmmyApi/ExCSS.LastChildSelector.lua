﻿---@class LastChildSelector : BaseSelector
---@field public Instance LastChildSelector
---@public
---@param friendlyFormat bool
---@param indentation number
---@return string
function LastChildSelector:ToString(friendlyFormat, indentation) end
