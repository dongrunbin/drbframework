﻿---@class IDataTableParser
---@public
---@param data Byte[]
---@return void
function IDataTableParser:Parse(data) end
---@public
---@return void
function IDataTableParser:Reset() end
