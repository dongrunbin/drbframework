﻿---@class DefaultInitializationErrorHandlerInternal : VuforiaMonoBehaviour
---@public
---@param initError number
---@return void
function DefaultInitializationErrorHandlerInternal:OnVuforiaInitializationError(initError) end
