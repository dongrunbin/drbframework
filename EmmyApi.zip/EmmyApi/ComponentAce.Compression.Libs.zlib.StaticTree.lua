﻿---@class StaticTree
