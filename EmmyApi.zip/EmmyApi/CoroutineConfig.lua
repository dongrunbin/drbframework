﻿---@class CoroutineConfig
---@field public LuaCallCSharp List`1
