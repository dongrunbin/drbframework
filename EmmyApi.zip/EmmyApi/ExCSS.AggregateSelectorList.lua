﻿---@class AggregateSelectorList : SelectorList
---@field public Delimiter string
---@public
---@param friendlyFormat bool
---@param indentation number
---@return string
function AggregateSelectorList:ToString(friendlyFormat, indentation) end
