﻿---@class IEntity
---@field public ComponentCount number
---@public
---@param value ComponentEventHandler
---@return void
function IEntity:add_OnComponentAdded(value) end
---@public
---@param value ComponentEventHandler
---@return void
function IEntity:remove_OnComponentAdded(value) end
---@public
---@param value ComponentEventHandler
---@return void
function IEntity:add_OnComponentRemoved(value) end
---@public
---@param value ComponentEventHandler
---@return void
function IEntity:remove_OnComponentRemoved(value) end
---@public
---@param component IComponent
---@return void
function IEntity:AddComponent(component) end
---@public
---@param componentName string
---@return IComponent
function IEntity:GetComponent(componentName) end
---@public
---@param condition Predicate`1
---@param components IList`1
---@return void
function IEntity:GetComponents(condition, components) end
---@public
---@return IComponent[]
function IEntity:GetAllComponents() end
---@public
---@param componentName string
---@return bool
function IEntity:HasComponent(componentName) end
---@public
---@param componentNames String[]
---@return bool
function IEntity:HasComponents(componentNames) end
---@public
---@param componentNames String[]
---@return bool
function IEntity:HasAnyComponent(componentNames) end
---@public
---@param componentName string
---@return void
function IEntity:RemoveComponent(componentName) end
---@public
---@return void
function IEntity:RemoveAllComponents() end
---@public
---@return void
function IEntity:OnDestroy() end
