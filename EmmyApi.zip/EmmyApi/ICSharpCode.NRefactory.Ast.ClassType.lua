﻿---@class ClassType : Enum
---@field public value__ number
---@field public Class number
---@field public Module number
---@field public Interface number
---@field public Struct number
---@field public Enum number
