﻿---@class IAudioSystem
---@field public MaxSameAudioCount number
---@field public SounderRoot Object
---@public
---@param audioAsset Object
---@param info AudioInfo
---@return void
function IAudioSystem:PlayAudio(audioAsset, info) end
---@public
---@return ISounder[]
function IAudioSystem:GetAllSounders() end
---@public
---@param audioId number
---@return void
function IAudioSystem:PauseAudio(audioId) end
---@public
---@param audioId number
---@return void
function IAudioSystem:ResumeAudio(audioId) end
---@public
---@param audioId number
---@return void
function IAudioSystem:StopAudio(audioId) end
---@public
---@return void
function IAudioSystem:StopAllAudio() end
