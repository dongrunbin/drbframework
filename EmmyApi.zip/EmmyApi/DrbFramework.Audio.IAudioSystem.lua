﻿---@class IAudioSystem
