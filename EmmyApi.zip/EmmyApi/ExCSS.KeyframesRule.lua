﻿---@class KeyframesRule : RuleSet
---@field public Identifier string
---@field public Declarations List`1
---@public
---@return string
function KeyframesRule:ToString() end
---@public
---@param friendlyFormat bool
---@param indentation number
---@return string
function KeyframesRule:ToString(friendlyFormat, indentation) end
