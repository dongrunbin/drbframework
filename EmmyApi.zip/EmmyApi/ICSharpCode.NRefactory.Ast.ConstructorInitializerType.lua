﻿---@class ConstructorInitializerType : Enum
---@field public value__ number
---@field public None number
---@field public Base number
---@field public This number
