﻿---@class IEntitySystem
