﻿---@class IEntitySystem
---@field public ComponentCount number
---@public
---@param value EntityEventHandler
---@return void
function IEntitySystem:add_OnEntityCreated(value) end
---@public
---@param value EntityEventHandler
---@return void
function IEntitySystem:remove_OnEntityCreated(value) end
---@public
---@param value EntityEventHandler
---@return void
function IEntitySystem:add_OnEntityDestroyed(value) end
---@public
---@param value EntityEventHandler
---@return void
function IEntitySystem:remove_OnEntityDestroyed(value) end
---@public
---@param entityType Type
---@return IEntity
function IEntitySystem:CreateEntity(entityType) end
---@public
---@return IEntity[]
function IEntitySystem:GetAllEntities() end
---@public
---@param entity IEntity
---@return void
function IEntitySystem:DestroyEntity(entity) end
---@public
---@param condition Predicate`1
---@param components IList`1
---@return void
function IEntitySystem:GetComponents(condition, components) end
