﻿---@class GeneralResourceHolder
---@field public AssetCount number
---@field public AssetBundleCount number
---@public
---@param assetName string
---@return bool
function GeneralResourceHolder:HasAsset(assetName) end
---@public
---@param assetName string
---@return Object
function GeneralResourceHolder:GetAsset(assetName) end
---@public
---@param assetName string
---@param asset Object
---@return void
function GeneralResourceHolder:AddAsset(assetName, asset) end
---@public
---@param assetName string
---@return void
function GeneralResourceHolder:RemoveAsset(assetName) end
---@public
---@param assetBundlePath string
---@return bool
function GeneralResourceHolder:HasAssetBundle(assetBundlePath) end
---@public
---@param assetBundlePath string
---@return Object
function GeneralResourceHolder:GetAssetBundle(assetBundlePath) end
---@public
---@param assetBundlePath string
---@param assetBundle Object
---@return void
function GeneralResourceHolder:AddAssetBundle(assetBundlePath, assetBundle) end
---@public
---@param assetBundlePath string
---@return void
function GeneralResourceHolder:RemoveAssetBundle(assetBundlePath) end
