﻿---@class Object
---@field public Name string
---@field public Target Object
---@field public LastUseTime number
