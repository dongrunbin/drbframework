﻿---@class NthFirstChildSelector : NthChildSelector
---@public
---@param friendlyFormat bool
---@param indentation number
---@return string
function NthFirstChildSelector:ToString(friendlyFormat, indentation) end
