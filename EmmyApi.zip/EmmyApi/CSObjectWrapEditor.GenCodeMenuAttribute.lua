﻿---@class GenCodeMenuAttribute : Attribute
