﻿---@class UGuiTextLocalizer : LocalizerComponent
---@field public Key string
---@field public Value string
