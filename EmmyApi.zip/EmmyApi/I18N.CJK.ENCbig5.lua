﻿---@class ENCbig5 : CP950
