﻿---@class Procedure : FsmState
