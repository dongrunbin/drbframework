﻿---@class PrimitiveTerm : Term
---@field public Value Object
---@field public PrimitiveType number
---@public
---@param unit number
---@return Nullable`1
function PrimitiveTerm:GetFloatValue(unit) end
---@public
---@return string
function PrimitiveTerm:ToString() end
