﻿---@class EntityEventHandler : MulticastDelegate
---@public
---@param entity IEntity
---@return void
function EntityEventHandler:Invoke(entity) end
---@public
---@param entity IEntity
---@param callback AsyncCallback
---@param object Object
---@return IAsyncResult
function EntityEventHandler:BeginInvoke(entity, callback, object) end
---@public
---@param result IAsyncResult
---@return void
function EntityEventHandler:EndInvoke(result) end
