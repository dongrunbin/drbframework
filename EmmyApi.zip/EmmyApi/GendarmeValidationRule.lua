﻿---@class GendarmeValidationRule
---@public
---@param userAssemblies IEnumerable`1
---@param options Object[]
---@return ValidationResult
function GendarmeValidationRule:Validate(userAssemblies, options) end
