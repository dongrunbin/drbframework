﻿---@class ScreenInfo : DebugFormBase
