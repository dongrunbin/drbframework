﻿---@class FsmLuaState : FsmState
---@field public StateName string
---@public
---@param userData Object
---@return void
function FsmLuaState:OnEnter(userData) end
