﻿---@class BrowserPrefixes
