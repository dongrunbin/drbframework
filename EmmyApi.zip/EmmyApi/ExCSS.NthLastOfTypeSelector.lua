﻿---@class NthLastOfTypeSelector : NthChildSelector
---@public
---@param friendlyFormat bool
---@param indentation number
---@return string
function NthLastOfTypeSelector:ToString(friendlyFormat, indentation) end
