﻿---@class StatementWithEmbeddedStatement : Statement
---@field public EmbeddedStatement Statement
