﻿---@class UICreater
---@public
---@param form IUIForm
---@return void
function UICreater:DestroyForm(form) end
---@public
---@param asset Object
---@param uiRoot Object
---@return IUIForm
function UICreater:InstantiateForm(asset, uiRoot) end
