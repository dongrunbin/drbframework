﻿---@class StylesheetReader
