﻿---@class DrbComponentInspector : InspectorEditorBase
---@public
---@return void
function DrbComponentInspector:OnInspectorGUI() end
