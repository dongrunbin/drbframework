﻿---@class FolderUtil
---@public
---@param path string
---@return void
function FolderUtil.OpenFolder(path) end
---@public
---@param path string
---@return void
function FolderUtil.SelectFile(path) end
