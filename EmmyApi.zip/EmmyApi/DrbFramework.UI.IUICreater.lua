﻿---@class IUICreater
---@public
---@param asset Object
---@param uiRoot Object
---@return IUIForm
function IUICreater:InstantiateForm(asset, uiRoot) end
---@public
---@param form IUIForm
---@return void
function IUICreater:DestroyForm(form) end
