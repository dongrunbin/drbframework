﻿---@class TimeInfo : DebugFormBase
