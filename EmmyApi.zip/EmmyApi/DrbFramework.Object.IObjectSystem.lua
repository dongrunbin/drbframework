﻿---@class IObjectSystem
