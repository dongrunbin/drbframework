﻿---@class UILuaForm : UIForm
---@public
---@return void
function UILuaForm:OnInit() end
---@public
---@return void
function UILuaForm:OnOpen() end
---@public
---@param elapseSeconds number
---@param realElapseSeconds number
---@return void
function UILuaForm:OnUpdate(elapseSeconds, realElapseSeconds) end
---@public
---@return void
function UILuaForm:OnClose() end
---@public
---@return void
function UILuaForm:OnBeforeDestroy() end
