﻿---@class CastType : Enum
---@field public value__ number
---@field public Cast number
---@field public TryCast number
---@field public Conversion number
---@field public PrimitiveConversion number
