﻿---@class ISupportsMedia
---@field public Media MediaTypeList
