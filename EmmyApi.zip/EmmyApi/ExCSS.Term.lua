﻿---@class Term
---@field public Inherit InheritTerm
