﻿---@class QueryExpressionClause : AbstractNode
---@field public IsNull bool
---@field public Null QueryExpressionClause
