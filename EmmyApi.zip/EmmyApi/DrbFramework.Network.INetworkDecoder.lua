﻿---@class INetworkDecoder
---@public
---@param channel INetworkChannel
---@param inData Stream
---@param outData Object&
---@return void
function INetworkDecoder:Decode(channel, inData, outData) end
