﻿---@class SelectorFactory
