﻿---@class ILuaSystem
---@field public LuaEnv LuaEnv
