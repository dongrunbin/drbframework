﻿---@class ExampleConfig
---@field public BlackList List`1
