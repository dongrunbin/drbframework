﻿---@class System : DebugFormBase
