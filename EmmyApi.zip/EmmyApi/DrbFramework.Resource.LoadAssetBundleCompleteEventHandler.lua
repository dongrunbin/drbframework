﻿---@class LoadAssetBundleCompleteEventHandler : MulticastDelegate
---@public
---@param args LoadAssetBundleCompleteEventArgs
---@return void
function LoadAssetBundleCompleteEventHandler:Invoke(args) end
---@public
---@param args LoadAssetBundleCompleteEventArgs
---@param callback AsyncCallback
---@param object Object
---@return IAsyncResult
function LoadAssetBundleCompleteEventHandler:BeginInvoke(args, callback, object) end
---@public
---@param result IAsyncResult
---@return void
function LoadAssetBundleCompleteEventHandler:EndInvoke(result) end
