﻿---@class OnUIFormBeforeDestroyAction : MulticastDelegate
---@public
---@return void
function OnUIFormBeforeDestroyAction:Invoke() end
---@public
---@param callback AsyncCallback
---@param object Object
---@return IAsyncResult
function OnUIFormBeforeDestroyAction:BeginInvoke(callback, object) end
---@public
---@param result IAsyncResult
---@return void
function OnUIFormBeforeDestroyAction:EndInvoke(result) end
