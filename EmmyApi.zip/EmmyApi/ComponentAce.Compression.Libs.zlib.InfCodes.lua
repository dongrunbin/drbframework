﻿---@class InfCodes
