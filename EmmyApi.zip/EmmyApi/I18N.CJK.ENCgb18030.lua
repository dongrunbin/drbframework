﻿---@class ENCgb18030 : GB18030Encoding
