﻿---@class IConflictResolver
---@public
---@param keyCombinationSequence List`1
---@param entries List`1
---@return void
function IConflictResolver:ResolveConflict(keyCombinationSequence, entries) end
