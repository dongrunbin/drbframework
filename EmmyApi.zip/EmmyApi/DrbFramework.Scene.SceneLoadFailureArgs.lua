﻿---@class SceneLoadFailureArgs : EventArgs
---@field public SceneName string
---@field public Error string
