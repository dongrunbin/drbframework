﻿---@class DocumentFunction : Enum
---@field public value__ number
---@field public Url number
---@field public UrlPrefix number
---@field public Domain number
---@field public RegExp number
