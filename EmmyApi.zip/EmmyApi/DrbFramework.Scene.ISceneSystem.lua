﻿---@class ISceneSystem
---@field public OnSceneLoaded SceneLoadedHandler
---@field public OnSceneUnloaded SceneUnloadedHandler
---@public
---@param sceneName string
---@return void
function ISceneSystem:LoadSceneAsync(sceneName) end
---@public
---@param sceneName string
---@return void
function ISceneSystem:AddSceneAsync(sceneName) end
---@public
---@param sceneName string
---@return void
function ISceneSystem:UnloadSceneAsync(sceneName) end
---@public
---@param sceneName string
---@return void
function ISceneSystem:LoadScene(sceneName) end
---@public
---@param sceneName string
---@return void
function ISceneSystem:AddScene(sceneName) end
---@public
---@param sceneName string
---@return void
function ISceneSystem:UnloadScene(sceneName) end
