﻿---@class OnUIFormInitAction : MulticastDelegate
---@public
---@param formGameObject GameObject
---@return void
function OnUIFormInitAction:Invoke(formGameObject) end
---@public
---@param formGameObject GameObject
---@param callback AsyncCallback
---@param object Object
---@return IAsyncResult
function OnUIFormInitAction:BeginInvoke(formGameObject, callback, object) end
---@public
---@param result IAsyncResult
---@return void
function OnUIFormInitAction:EndInvoke(result) end
