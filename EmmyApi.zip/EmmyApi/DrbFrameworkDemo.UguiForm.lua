﻿---@class UguiForm : UIForm
---@field public Depth number
