﻿---@class EntitySystem
---@field public ComponentCount number
---@field public Priority number
---@public
---@param value EntityEventHandler
---@return void
function EntitySystem:add_OnEntityCreated(value) end
---@public
---@param value EntityEventHandler
---@return void
function EntitySystem:remove_OnEntityCreated(value) end
---@public
---@param value EntityEventHandler
---@return void
function EntitySystem:add_OnEntityDestroyed(value) end
---@public
---@param value EntityEventHandler
---@return void
function EntitySystem:remove_OnEntityDestroyed(value) end
---@public
---@param entityType Type
---@return IEntity
function EntitySystem:CreateEntity(entityType) end
---@public
---@return IEntity[]
function EntitySystem:GetAllEntities() end
---@public
---@param entity IEntity
---@return void
function EntitySystem:DestroyEntity(entity) end
---@public
---@return void
function EntitySystem:DestroyAllEntities() end
---@public
---@param condition Predicate`1
---@param components IList`1
---@return void
function EntitySystem:GetComponents(condition, components) end
---@public
---@param elapseSeconds number
---@param realElapseSeconds number
---@return void
function EntitySystem:Update(elapseSeconds, realElapseSeconds) end
---@public
---@return void
function EntitySystem:Shutdown() end
