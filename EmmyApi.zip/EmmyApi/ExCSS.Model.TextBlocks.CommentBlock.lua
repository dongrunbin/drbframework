﻿---@class CommentBlock : Block
---@public
---@return string
function CommentBlock:ToString() end
