﻿---@class CharacterSetRule : RuleSet
---@field public Encoding string
---@public
---@return string
function CharacterSetRule:ToString() end
---@public
---@param friendlyFormat bool
---@param indentation number
---@return string
function CharacterSetRule:ToString(friendlyFormat, indentation) end
