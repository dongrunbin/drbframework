﻿---@class DownloadFailureEventArgs : EventArgs
---@field public DownloadUri string
---@field public SavePath string
---@field public Error string
---@field public UserData Object
