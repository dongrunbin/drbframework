﻿---@class UnitBlock : Block
---@public
---@return string
function UnitBlock:ToString() end
