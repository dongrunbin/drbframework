﻿---@class CombinatorSelector : ValueType
---@field public Selector BaseSelector
---@field public Delimiter number
---@field public Character Char
