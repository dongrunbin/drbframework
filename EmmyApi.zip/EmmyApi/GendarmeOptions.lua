﻿---@class GendarmeOptions : ValueType
---@field public RuleSet string
---@field public ConfigFilePath string
---@field public UserAssemblies String[]
