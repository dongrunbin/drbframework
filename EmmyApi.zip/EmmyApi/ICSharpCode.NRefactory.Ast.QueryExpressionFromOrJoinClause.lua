﻿---@class QueryExpressionFromOrJoinClause : QueryExpressionClause
---@field public Type TypeReference
---@field public Identifier string
---@field public InExpression Expression
