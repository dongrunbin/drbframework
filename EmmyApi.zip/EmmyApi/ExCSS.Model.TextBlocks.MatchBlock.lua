﻿---@class MatchBlock : Block
---@public
---@return string
function MatchBlock:ToString() end
