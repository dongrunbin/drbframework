﻿---@class ConditionPosition : Enum
---@field public value__ number
---@field public None number
---@field public Start number
---@field public End number
