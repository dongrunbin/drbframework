﻿---@class IEnvironmentInformationProvider
---@public
---@param reflectionTypeName string
---@param typeParameterCount number
---@param fieldName string
---@return bool
function IEnvironmentInformationProvider:HasField(reflectionTypeName, typeParameterCount, fieldName) end
