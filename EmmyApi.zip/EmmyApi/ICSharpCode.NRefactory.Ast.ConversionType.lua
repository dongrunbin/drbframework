﻿---@class ConversionType : Enum
---@field public value__ number
---@field public None number
---@field public Implicit number
---@field public Explicit number
