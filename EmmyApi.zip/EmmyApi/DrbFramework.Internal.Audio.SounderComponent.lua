﻿---@class SounderComponent : MonoBehaviour
---@field public AudioId number
---@field public Tag string
---@field public FollowTarget Object
---@field public Time number
---@field public Mute bool
---@field public Loop bool
---@field public Volume number
---@field public FadeTime number
---@field public Pitch number
---@field public PanStereo number
---@field public SpatialBlend number
---@field public MaxDistance number
---@field public DopplerLevel number
---@field public AudioAsset Object
---@field public IsStopped bool
---@public
---@return void
function SounderComponent:Pause() end
---@public
---@return void
function SounderComponent:Play() end
---@public
---@param audioAsset Object
---@param info AudioInfo
---@return void
function SounderComponent:Reset(audioAsset, info) end
---@public
---@return void
function SounderComponent:Stop() end
---@public
---@return void
function SounderComponent:Follow() end
