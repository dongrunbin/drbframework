﻿---@class UIFormOpenedEventHandler : MulticastDelegate
---@public
---@param sender Object
---@param args UIFormOpenedEventArgs
---@return void
function UIFormOpenedEventHandler:Invoke(sender, args) end
---@public
---@param sender Object
---@param args UIFormOpenedEventArgs
---@param callback AsyncCallback
---@param object Object
---@return IAsyncResult
function UIFormOpenedEventHandler:BeginInvoke(sender, args, callback, object) end
---@public
---@param result IAsyncResult
---@return void
function UIFormOpenedEventHandler:EndInvoke(result) end
