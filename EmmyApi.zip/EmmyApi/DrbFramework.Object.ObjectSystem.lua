﻿---@class ObjectSystem
---@field public Priority number
---@public
---@return void
function ObjectSystem:Shutdown() end
---@public
---@param elapseSeconds number
---@param realElapseSeconds number
---@return void
function ObjectSystem:Update(elapseSeconds, realElapseSeconds) end
---@public
---@param assetBundlePath string
---@param assetName string
---@return void
function ObjectSystem:CreateObject(assetBundlePath, assetName) end
---@public
---@param assetPath string
---@return void
function ObjectSystem:CreateObject(assetPath) end
