﻿---@class CustomGenTask : ValueType
---@field public Data LuaTable
---@field public Output TextWriter
