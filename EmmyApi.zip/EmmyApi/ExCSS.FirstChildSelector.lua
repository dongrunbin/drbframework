﻿---@class FirstChildSelector : BaseSelector
---@field public Instance FirstChildSelector
---@public
---@param friendlyFormat bool
---@param indentation number
---@return string
function FirstChildSelector:ToString(friendlyFormat, indentation) end
