﻿---@class ISceneLoader
---@field public OnSceneLoaded SceneLoadedHandler
---@field public OnSceneUnloaded SceneUnloadedHandler
---@public
---@param sceneName string
---@return void
function ISceneLoader:LoadScene(sceneName) end
---@public
---@param sceneName string
---@return void
function ISceneLoader:AddScene(sceneName) end
---@public
---@param sceneName string
---@return void
function ISceneLoader:UnloadScene(sceneName) end
---@public
---@param sceneName string
---@return void
function ISceneLoader:LoadSceneAsync(sceneName) end
---@public
---@param sceneName string
---@return void
function ISceneLoader:AddSceneAsync(sceneName) end
---@public
---@param sceneName string
---@return void
function ISceneLoader:UnloadSceneAsync(sceneName) end
