﻿---@class IUIGroup
