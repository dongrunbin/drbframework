﻿---@class DesktopStandaloneUserBuildSettings
