﻿---@class ISounderCreater
---@public
---@param soundRoot Object
---@return ISounder
function ISounderCreater:CreateSounder(soundRoot) end
