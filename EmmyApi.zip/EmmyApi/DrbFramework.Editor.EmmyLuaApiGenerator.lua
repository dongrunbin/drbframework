﻿---@class EmmyLuaApiGenerator
