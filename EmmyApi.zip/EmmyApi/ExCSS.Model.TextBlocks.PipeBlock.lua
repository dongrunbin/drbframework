﻿---@class PipeBlock : Block
---@public
---@return string
function PipeBlock:ToString() end
