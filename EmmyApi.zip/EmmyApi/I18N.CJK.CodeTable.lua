﻿---@class CodeTable
---@public
---@return void
function CodeTable:Dispose() end
---@public
---@param num number
---@return Byte[]
function CodeTable:GetSection(num) end
