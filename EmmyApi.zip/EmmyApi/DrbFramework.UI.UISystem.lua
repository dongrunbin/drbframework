﻿---@class UISystem
---@field public UIRoot Object
---@field public Priority number
---@public
---@return void
function UISystem:Shutdown() end
---@public
---@param elapseSeconds number
---@param realElapseSeconds number
---@return void
function UISystem:Update(elapseSeconds, realElapseSeconds) end
---@public
---@param assetPath string
---@param mode number
---@return IUIForm
function UISystem:OpenForm(assetPath, mode) end
---@public
---@param assetBundlePath string
---@param assetName string
---@param mode number
---@return IUIForm
function UISystem:OpenForm(assetBundlePath, assetName, mode) end
---@public
---@param form IUIForm
---@return void
function UISystem:OpenForm(form) end
---@public
---@param assetPath string
---@param assetName string
---@param onOpened UIFormOpenedEventHandler
---@param userData Object
---@return void
function UISystem:OpenFormAsync(assetPath, assetName, onOpened, userData) end
---@public
---@param form IUIForm
---@return void
function UISystem:CloseForm(form) end
---@public
---@param form IUIForm
---@return void
function UISystem:DestroyForm(form) end
