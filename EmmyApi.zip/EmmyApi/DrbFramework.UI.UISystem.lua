﻿---@class UISystem
---@field public Priority number
---@field public UIRoot Object
---@field public FormCount number
---@field public ShowingFormCount number
---@field public ClosedFormCount number
---@public
---@return void
function UISystem:Shutdown() end
---@public
---@param elapseSeconds number
---@param realElapseSeconds number
---@return void
function UISystem:Update(elapseSeconds, realElapseSeconds) end
---@public
---@param formName string
---@param formAsset Object
---@return IUIForm
function UISystem:OpenForm(formName, formAsset) end
---@public
---@param form IUIForm
---@return void
function UISystem:OpenForm(form) end
---@public
---@param form IUIForm
---@return void
function UISystem:CloseForm(form) end
---@public
---@return void
function UISystem:CloseAllForm() end
---@public
---@param form IUIForm
---@return void
function UISystem:DestroyForm(form) end
---@public
---@return void
function UISystem:DestroyAllForm() end
---@public
---@param assetPath string
---@return IUIForm
function UISystem:OpenInternalForm(assetPath) end
---@public
---@param assetPath string
---@param callback OpenFormComplete
---@return void
function UISystem:OpenFormAsync(assetPath, callback) end
