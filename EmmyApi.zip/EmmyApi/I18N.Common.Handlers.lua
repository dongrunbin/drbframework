﻿---@class Handlers
---@field public List String[]
---@public
---@param name string
---@return string
function Handlers.GetAlias(name) end
