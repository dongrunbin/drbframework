﻿---@class OptionType : Enum
---@field public value__ number
---@field public None number
---@field public Explicit number
---@field public Strict number
---@field public CompareBinary number
---@field public CompareText number
---@field public Infer number
