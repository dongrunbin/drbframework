﻿---@class BracketBlock : Block
---@public
---@return string
function BracketBlock:ToString() end
---@public
---@param friendlyFormat bool
---@param indentation number
---@return string
function BracketBlock:ToString(friendlyFormat, indentation) end
