﻿---@class ConfigXmlTextReader : XmlTextReader
---@field public Filename string
