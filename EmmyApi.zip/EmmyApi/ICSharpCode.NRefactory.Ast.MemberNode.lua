﻿---@class MemberNode : ParametrizedNode
---@field public InterfaceImplementations List`1
---@field public TypeReference TypeReference
