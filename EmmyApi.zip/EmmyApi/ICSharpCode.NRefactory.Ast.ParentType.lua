﻿---@class ParentType : Enum
---@field public value__ number
---@field public ClassOrStruct number
---@field public InterfaceOrEnum number
---@field public Namespace number
---@field public Unknown number
