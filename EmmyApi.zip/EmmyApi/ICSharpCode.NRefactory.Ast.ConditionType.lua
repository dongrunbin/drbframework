﻿---@class ConditionType : Enum
---@field public value__ number
---@field public None number
---@field public Until number
---@field public While number
---@field public DoWhile number
