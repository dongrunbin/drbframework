﻿---@class Strings
---@public
---@param tag string
---@return string
function Strings.GetString(tag) end
