﻿---@class BuildFromCLI
---@public
---@return void
function BuildFromCLI.BuildFromUnityMenu() end
---@public
---@return void
function BuildFromCLI.Build() end
