﻿---@class RangeBlock : Block
---@public
---@return string
function RangeBlock:ToString() end
