﻿---@class IUIForm
---@public
---@return void
function IUIForm:OnInit() end
---@public
---@return void
function IUIForm:OnShow() end
---@public
---@return void
function IUIForm:OnHide() end
---@public
---@return void
function IUIForm:OnBeforeDestroy() end
