﻿---@class IUIForm
---@field public AssetPath string
---@field public AssetName string
---@field public Depth number
---@field public IsShow bool
---@public
---@return void
function IUIForm:OnInit() end
---@public
---@return void
function IUIForm:OnOpen() end
---@public
---@return void
function IUIForm:OnCover() end
---@public
---@return void
function IUIForm:OnFocus() end
---@public
---@param elapseSeconds number
---@param realElapseSeconds number
---@return void
function IUIForm:OnUpdate(elapseSeconds, realElapseSeconds) end
---@public
---@return void
function IUIForm:OnClose() end
---@public
---@return void
function IUIForm:OnBeforeDestroy() end
