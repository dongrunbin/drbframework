﻿---@class SoundPlayer : SounderComponent
---@field public AudioAsset Object
---@field public IsStopped bool
---@field public AudioId number
---@field public Tag string
---@field public FollowTarget Object
---@field public FadeTime number
---@field public Time number
---@field public Mute bool
---@field public Loop bool
---@field public Volume number
---@field public Pitch number
---@field public PanStereo number
---@field public SpatialBlend number
---@field public MaxDistance number
---@field public DopplerLevel number
---@public
---@return void
function SoundPlayer:Follow() end
---@public
---@return void
function SoundPlayer:Pause() end
---@public
---@return void
function SoundPlayer:Play() end
---@public
---@param audioAsset Object
---@param info AudioInfo
---@return void
function SoundPlayer:Reset(audioAsset, info) end
---@public
---@return void
function SoundPlayer:Stop() end
