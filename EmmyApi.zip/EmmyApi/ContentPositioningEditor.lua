﻿---@class ContentPositioningEditor : Editor
---@public
---@return void
function ContentPositioningEditor:OnInspectorGUI() end
