﻿---@class OnUIFormUpdateAction : MulticastDelegate
---@public
---@param elapseSeconds number
---@param realElapseSeconds number
---@return void
function OnUIFormUpdateAction:Invoke(elapseSeconds, realElapseSeconds) end
---@public
---@param elapseSeconds number
---@param realElapseSeconds number
---@param callback AsyncCallback
---@param object Object
---@return IAsyncResult
function OnUIFormUpdateAction:BeginInvoke(elapseSeconds, realElapseSeconds, callback, object) end
---@public
---@param result IAsyncResult
---@return void
function OnUIFormUpdateAction:EndInvoke(result) end
