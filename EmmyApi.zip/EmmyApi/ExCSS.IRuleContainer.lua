﻿---@class IRuleContainer
---@field public Declarations List`1
