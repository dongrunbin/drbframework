﻿---@class ContinueType : Enum
---@field public value__ number
---@field public None number
---@field public Do number
---@field public For number
---@field public While number
