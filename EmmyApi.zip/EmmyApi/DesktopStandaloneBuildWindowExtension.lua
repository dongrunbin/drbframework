﻿---@class DesktopStandaloneBuildWindowExtension : DefaultBuildWindowExtension
---@public
---@return void
function DesktopStandaloneBuildWindowExtension:ShowPlatformBuildOptions() end
---@public
---@return bool
function DesktopStandaloneBuildWindowExtension:EnabledBuildButton() end
---@public
---@return bool
function DesktopStandaloneBuildWindowExtension:EnabledBuildAndRunButton() end
---@public
---@return bool
function DesktopStandaloneBuildWindowExtension:ShouldDrawWaitForManagedDebugger() end
