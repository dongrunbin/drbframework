﻿---@class SceneUnloadedEventArgs : EventArgs
---@field public SceneName string
