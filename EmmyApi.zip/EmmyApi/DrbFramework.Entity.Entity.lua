﻿---@class Entity
---@field public ComponentCount number
---@public
---@param value ComponentEventHandler
---@return void
function Entity:add_OnComponentAdded(value) end
---@public
---@param value ComponentEventHandler
---@return void
function Entity:remove_OnComponentAdded(value) end
---@public
---@param value ComponentEventHandler
---@return void
function Entity:add_OnComponentRemoved(value) end
---@public
---@param value ComponentEventHandler
---@return void
function Entity:remove_OnComponentRemoved(value) end
---@public
---@param component IComponent
---@return void
function Entity:AddComponent(component) end
---@public
---@param componentName string
---@return IComponent
function Entity:GetComponent(componentName) end
---@public
---@param condition Predicate`1
---@param components IList`1
---@return void
function Entity:GetComponents(condition, components) end
---@public
---@return IComponent[]
function Entity:GetAllComponents() end
---@public
---@param componentName string
---@return bool
function Entity:HasComponent(componentName) end
---@public
---@param componentNames String[]
---@return bool
function Entity:HasComponents(componentNames) end
---@public
---@param componentNames String[]
---@return bool
function Entity:HasAnyComponent(componentNames) end
---@public
---@param componentName string
---@return void
function Entity:RemoveComponent(componentName) end
---@public
---@return void
function Entity:RemoveAllComponents() end
---@public
---@return void
function Entity:OnDestroy() end
