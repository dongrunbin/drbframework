﻿---@class AudioSystem
---@field public Priority number
---@field public MaxSameAudioCount number
---@field public SounderRoot Object
---@public
---@param audioAsset Object
---@param info AudioInfo
---@return void
function AudioSystem:PlayAudio(audioAsset, info) end
---@public
---@return ISounder[]
function AudioSystem:GetAllSounders() end
---@public
---@param audioId number
---@return void
function AudioSystem:PauseAudio(audioId) end
---@public
---@param audioId number
---@return void
function AudioSystem:ResumeAudio(audioId) end
---@public
---@param audioId number
---@return void
function AudioSystem:StopAudio(audioId) end
---@public
---@return void
function AudioSystem:StopAllAudio() end
---@public
---@param elapseSeconds number
---@param realElapseSeconds number
---@return void
function AudioSystem:Update(elapseSeconds, realElapseSeconds) end
---@public
---@return void
function AudioSystem:Shutdown() end
---@public
---@param assetBundlePath string
---@param assetName string
---@param mode number
---@return void
function AudioSystem:PlayBGM(assetBundlePath, assetName, mode) end
