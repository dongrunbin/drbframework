﻿---@class GeneratorConfig
---@field public common_path string
