﻿---@class InfBlocks
