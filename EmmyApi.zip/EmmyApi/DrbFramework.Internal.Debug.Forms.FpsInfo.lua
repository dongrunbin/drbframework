﻿---@class FpsInfo : DebugFormBase
---@public
---@param elapseSeconds number
---@param realElapseSeconds number
---@return void
function FpsInfo:OnUpdate(elapseSeconds, realElapseSeconds) end
---@public
---@return void
function FpsInfo:OnDraw() end
