﻿---@class Tree
