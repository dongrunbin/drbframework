﻿---@class ICompilerSettings
---@field public LibPaths String[]
---@field public CompilerPath string
---@field public LinkerPath string
---@field public MachineSpecification string
