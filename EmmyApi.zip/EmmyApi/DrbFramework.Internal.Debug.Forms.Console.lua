﻿---@class Console : DebugFormBase
---@public
---@return void
function Console:OnInit() end
---@public
---@return void
function Console:OnDestroy() end
