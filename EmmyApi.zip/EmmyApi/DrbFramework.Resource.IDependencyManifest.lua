﻿---@class IDependencyManifest
---@public
---@param assetBundlePath string
---@return String[]
function IDependencyManifest:GetAllDependencies(assetBundlePath) end
