﻿---@class ResourceLoaderComponent : MonoBehaviour
---@field public OnLoadAssetComplete LoadAssetCompleteEventHandler
---@field public OnLoadAssetBundleBytesComplete LoadAssetBundleBytesCompleteEventHandler
---@public
---@param filePath string
---@param mode number
---@return Byte[]
function ResourceLoaderComponent:LoadFile(filePath, mode) end
---@public
---@param assetBundlePath string
---@param mode number
---@return Byte[]
function ResourceLoaderComponent:LoadAssetBundleBytes(assetBundlePath, mode) end
---@public
---@param assetBundle Object
---@param assetName string
---@param mode number
---@return Object
function ResourceLoaderComponent:LoadAssetFromAssetBundle(assetBundle, assetName, mode) end
---@public
---@param assetPath string
---@param mode number
---@return Object
function ResourceLoaderComponent:LoadAsset(assetPath, mode) end
---@public
---@param assetBundlePath string
---@param mode number
---@return void
function ResourceLoaderComponent:LoadAssetBundleBytesAsync(assetBundlePath, mode) end
---@public
---@param assetBundle Object
---@param assetName string
---@param mode number
---@return void
function ResourceLoaderComponent:LoadAssetFromAssetBundleAsync(assetBundle, assetName, mode) end
---@public
---@param assetPath string
---@param mode number
---@return void
function ResourceLoaderComponent:LoadAssetAsync(assetPath, mode) end
---@public
---@param assetBundle Object
---@param mode number
---@return void
function ResourceLoaderComponent:ReleaseAssetBundle(assetBundle, mode) end
---@public
---@param asset Object
---@param mode number
---@return void
function ResourceLoaderComponent:ReleaseAsset(asset, mode) end
