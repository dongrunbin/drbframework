﻿---@class DebugFormBase
---@field public FormName string
---@public
---@return void
function DebugFormBase:OnDestroy() end
---@public
---@return void
function DebugFormBase:OnDraw() end
---@public
---@return void
function DebugFormBase:OnHide() end
---@public
---@return void
function DebugFormBase:OnInit() end
---@public
---@return void
function DebugFormBase:OnShow() end
---@public
---@param elapseSeconds number
---@param realElapseSeconds number
---@return void
function DebugFormBase:OnUpdate(elapseSeconds, realElapseSeconds) end
