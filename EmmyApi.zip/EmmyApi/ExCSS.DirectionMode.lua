﻿---@class DirectionMode : Enum
---@field public value__ number
---@field public LeftToRight number
---@field public RightToLeft number
