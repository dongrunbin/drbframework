﻿---@class BaseSelector
---@public
---@return string
function BaseSelector:ToString() end
---@public
---@param friendlyFormat bool
---@param indentation number
---@return string
function BaseSelector:ToString(friendlyFormat, indentation) end
