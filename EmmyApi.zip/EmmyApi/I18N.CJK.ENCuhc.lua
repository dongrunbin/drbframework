﻿---@class ENCuhc : CP949
