﻿---@class ISounder
---@field public AudioId number
---@field public Tag string
---@field public FollowTarget Object
---@field public Time number
---@field public Mute bool
---@field public Loop bool
---@field public Volume number
---@field public FadeTime number
---@field public Pitch number
---@field public PanStereo number
---@field public SpatialBlend number
---@field public MaxDistance number
---@field public DopplerLevel number
---@field public AudioAsset Object
---@field public IsStopped bool
---@public
---@param audioAsset Object
---@param info AudioInfo
---@return void
function ISounder:Reset(audioAsset, info) end
---@public
---@return void
function ISounder:Play() end
---@public
---@return void
function ISounder:Pause() end
---@public
---@return void
function ISounder:Stop() end
---@public
---@return void
function ISounder:Follow() end
