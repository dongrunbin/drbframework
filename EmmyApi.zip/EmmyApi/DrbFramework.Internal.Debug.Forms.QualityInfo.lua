﻿---@class QualityInfo : DebugFormBase
