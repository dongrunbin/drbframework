﻿---@class Statement : AbstractNode
---@field public Null Statement
---@field public IsNull bool
---@public
---@param statement Statement
---@return Statement
function Statement.CheckNull(statement) end
