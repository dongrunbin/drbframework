﻿---@class LaunchProcedure : Procedure
---@public
---@param userData Object
---@return void
function LaunchProcedure:OnEnter(userData) end
