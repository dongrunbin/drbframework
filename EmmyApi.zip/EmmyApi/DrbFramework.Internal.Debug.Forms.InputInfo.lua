﻿---@class InputInfo : DebugFormBase
