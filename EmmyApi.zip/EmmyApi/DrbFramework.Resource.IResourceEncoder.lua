﻿---@class IResourceEncoder
---@public
---@param filePath string
---@param assetBundleData Byte[]
---@return Byte[]
function IResourceEncoder:EncodeAssetBundle(filePath, assetBundleData) end
