﻿---@class UpdatesChecker
