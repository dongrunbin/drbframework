﻿---@class IResourceDecoder
---@public
---@param data Byte[]
---@return Object
function IResourceDecoder:DecodeAssetBundle(data) end
