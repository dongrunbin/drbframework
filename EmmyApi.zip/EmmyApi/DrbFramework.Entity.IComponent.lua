﻿---@class IComponent
---@field public Name string
