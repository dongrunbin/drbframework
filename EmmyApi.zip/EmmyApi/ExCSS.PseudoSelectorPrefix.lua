﻿---@class PseudoSelectorPrefix
