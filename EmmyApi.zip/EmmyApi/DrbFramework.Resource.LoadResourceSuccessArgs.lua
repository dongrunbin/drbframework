﻿---@class LoadResourceSuccessArgs : EventArgs
---@field public AssetPath string
---@field public AssetName string
---@field public Asset Object
