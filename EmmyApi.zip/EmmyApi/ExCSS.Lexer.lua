﻿---@class Lexer
