﻿---@class ExampleDecoder
---@public
---@param channel INetworkChannel
---@param inData Stream
---@param outData Object&
---@return void
function ExampleDecoder:Decode(channel, inData, outData) end
