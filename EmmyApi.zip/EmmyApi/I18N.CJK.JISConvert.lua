﻿---@class JISConvert
---@field public jisx0208ToUnicode Byte[]
---@field public jisx0212ToUnicode Byte[]
---@field public cjkToJis Byte[]
---@field public greekToJis Byte[]
---@field public extraToJis Byte[]
---@field public Convert JISConvert
