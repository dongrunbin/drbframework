﻿---@class DownloadUpdateEventArgs : EventArgs
---@field public DownloadUri string
---@field public SavePath string
---@field public DownloadLength number
---@field public UserData Object
