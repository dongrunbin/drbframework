﻿---@class IDebugForm
---@field public FormName string
---@public
---@return void
function IDebugForm:OnInit() end
---@public
---@return void
function IDebugForm:OnShow() end
---@public
---@return void
function IDebugForm:OnHide() end
---@public
---@param elapseSeconds number
---@param realElapseSeconds number
---@return void
function IDebugForm:OnUpdate(elapseSeconds, realElapseSeconds) end
---@public
---@return void
function IDebugForm:OnDraw() end
---@public
---@return void
function IDebugForm:OnDestroy() end
