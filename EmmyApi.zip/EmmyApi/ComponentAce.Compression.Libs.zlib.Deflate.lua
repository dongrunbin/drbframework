﻿---@class Deflate
