﻿---@class NthLastChildSelector : NthChildSelector
---@public
---@param friendlyFormat bool
---@param indentation number
---@return string
function NthLastChildSelector:ToString(friendlyFormat, indentation) end
