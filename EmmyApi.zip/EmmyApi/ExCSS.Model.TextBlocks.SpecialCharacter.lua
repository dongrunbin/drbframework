﻿---@class SpecialCharacter : CharacterBlock
---@public
---@return string
function SpecialCharacter:ToString() end
