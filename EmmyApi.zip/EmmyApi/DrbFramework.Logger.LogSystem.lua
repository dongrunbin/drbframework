﻿---@class LogSystem
---@field public LogLevel number
---@field public TraceColor string
---@field public DebugColor string
---@field public InfoColor string
---@field public WarnColor string
---@field public ErrorColor string
---@field public Priority number
---@public
---@param elapseSeconds number
---@param realElapseSeconds number
---@return void
function LogSystem:Update(elapseSeconds, realElapseSeconds) end
---@public
---@return void
function LogSystem:Shutdown() end
---@public
---@param level number
---@param message Object
---@return void
function LogSystem:Log(level, message) end
