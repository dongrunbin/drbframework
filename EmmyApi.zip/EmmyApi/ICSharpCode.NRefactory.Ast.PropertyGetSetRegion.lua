﻿---@class PropertyGetSetRegion : AttributedNode
---@field public Block BlockStatement
---@field public IsNull bool
