﻿---@class OnUIFormHideAction : MulticastDelegate
---@public
---@return void
function OnUIFormHideAction:Invoke() end
---@public
---@param callback AsyncCallback
---@param object Object
---@return IAsyncResult
function OnUIFormHideAction:BeginInvoke(callback, object) end
---@public
---@param result IAsyncResult
---@return void
function OnUIFormHideAction:EndInvoke(result) end
