﻿---@class ENCeuc_kr : CP51949
