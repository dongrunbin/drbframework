﻿---@class ParserError : Enum
---@field public value__ number
---@field public EndOfFile number
---@field public UnexpectedLineBreak number
---@field public InvalidCharacter number
---@field public UnexpectedCommentToken number
