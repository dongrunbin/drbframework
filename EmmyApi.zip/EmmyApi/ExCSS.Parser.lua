﻿---@class Parser
---@public
---@param css string
---@return StyleSheet
function Parser:Parse(css) end
