﻿---@class DownloadSuccessEventArgs : EventArgs
---@field public DownloadUri string
---@field public SavePath string
---@field public Data Byte[]
---@field public UserData Object
