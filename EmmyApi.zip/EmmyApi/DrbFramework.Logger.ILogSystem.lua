﻿---@class ILogSystem
---@field public LogLevel number
---@field public TraceColor string
---@field public DebugColor string
---@field public InfoColor string
---@field public WarnColor string
---@field public ErrorColor string
---@public
---@param level number
---@param message Object
---@return void
function ILogSystem:Log(level, message) end
