﻿---@class FieldDirection : Enum
---@field public value__ number
---@field public None number
---@field public In number
---@field public Out number
---@field public Ref number
