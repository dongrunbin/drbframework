﻿---@class AssetBundleWindow : EditorWindow
