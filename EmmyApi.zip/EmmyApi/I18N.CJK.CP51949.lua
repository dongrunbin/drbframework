﻿---@class CP51949 : KoreanEncoding
---@field public BodyName string
---@field public EncodingName string
---@field public HeaderName string
---@field public WebName string
