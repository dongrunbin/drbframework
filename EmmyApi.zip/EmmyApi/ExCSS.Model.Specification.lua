﻿---@class Specification
