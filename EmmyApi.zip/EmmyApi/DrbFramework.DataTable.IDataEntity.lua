﻿---@class IDataEntity
---@field public Id number
---@field public DataRow IDataRow
---@public
---@param row IDataRow
---@return void
function IDataEntity:MakeEntity(row) end
