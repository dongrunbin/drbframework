﻿---@class IDataEntity
---@field public Id number
---@public
---@param row IDataRow
---@return void
function IDataEntity:MakeEntity(row) end
