﻿---@class TypeExtensions
---@public
---@param type Type
---@return String[]
function TypeExtensions.GetAllImplementationNames(type) end
---@public
---@param type Type
---@return Type[]
function TypeExtensions.GetAllImplementations(type) end
