﻿---@class OnUIFormShowAction : MulticastDelegate
---@public
---@return void
function OnUIFormShowAction:Invoke() end
---@public
---@param callback AsyncCallback
---@param object Object
---@return IAsyncResult
function OnUIFormShowAction:BeginInvoke(callback, object) end
---@public
---@param result IAsyncResult
---@return void
function OnUIFormShowAction:EndInvoke(result) end
