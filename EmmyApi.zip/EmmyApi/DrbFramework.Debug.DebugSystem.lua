﻿---@class DebugSystem
---@field public Priority number
---@field public CurrentForm IDebugForm
---@public
---@param formName string
---@return IDebugForm
function DebugSystem:GetDebugForm(formName) end
---@public
---@param type Type
---@return IDebugForm
function DebugSystem:GetDebugForm(type) end
---@public
---@return IDebugForm[]
function DebugSystem:GetAllDebugForms() end
---@public
---@return String[]
function DebugSystem:GetAllDebugFormNames() end
---@public
---@param type Type
---@return void
function DebugSystem:OpenDebugForm(type) end
---@public
---@param formName string
---@return void
function DebugSystem:OpenDebugForm(formName) end
---@public
---@return void
function DebugSystem:CloseCurrentForm() end
---@public
---@param form IDebugForm
---@return void
function DebugSystem:RegisterDebugForm(form) end
---@public
---@return void
function DebugSystem:Shutdown() end
---@public
---@param elapseSeconds number
---@param realElapseSeconds number
---@return void
function DebugSystem:Update(elapseSeconds, realElapseSeconds) end
---@public
---@return void
function DebugSystem:Draw() end
