﻿---@class CP50221 : ISO2022JPEncoding
---@field public EncodingName string
