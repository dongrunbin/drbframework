﻿---@class Foo1Parent
