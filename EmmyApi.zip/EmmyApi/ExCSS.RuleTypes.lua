﻿---@class RuleTypes
