﻿---@class TestDecoder
---@public
---@param channel INetworkChannel
---@param inData Stream
---@param outData Object&
---@return void
function TestDecoder:Decode(channel, inData, outData) end
