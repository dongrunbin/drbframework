﻿---@class ExampleEncoder
---@public
---@param channel INetworkChannel
---@param inData Object
---@param outData Stream
---@return void
function ExampleEncoder:Encode(channel, inData, outData) end
