﻿---@class EventAddRemoveRegion : AttributedNode
---@field public Block BlockStatement
---@field public Parameters List`1
---@field public IsNull bool
